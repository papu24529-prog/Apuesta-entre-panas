import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Tag, 
  RotateCw, 
  Sparkles, 
  Flame, 
  SlidersHorizontal,
  FileArchive,
  Trophy,
  Dices,
  CheckCircle2,
  Trash2
} from 'lucide-react';
import { Bet, BetCategory, Pana, RouletteItem } from './types';
import { 
  INITIAL_PANAS, 
  INITIAL_CATEGORIES, 
  INITIAL_BETS, 
  INITIAL_ROULETTE_ITEMS 
} from './data/initialData';
import { Header } from './components/Header';
import { BetCard } from './components/BetCard';
import { CreateBetModal } from './components/CreateBetModal';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { ResolveBetModal } from './components/ResolveBetModal';
import { ZipExportModal } from './components/ZipExportModal';
import { RouletteGame } from './components/RouletteGame';
import { DiceGame } from './components/DiceGame';
import { CoinGame } from './components/CoinGame';
import { PanasLeaderboard } from './components/PanasLeaderboard';
import { playClickSound, playWinSound } from './utils/audio';

export default function App() {
  // LocalStorage Persisted States
  const [panas, setPanas] = useState<Pana[]>(() => {
    const saved = localStorage.getItem('panas_data');
    return saved ? JSON.parse(saved) : INITIAL_PANAS;
  });

  const [categories, setCategories] = useState<BetCategory[]>(() => {
    const saved = localStorage.getItem('categories_data');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [bets, setBets] = useState<Bet[]>(() => {
    const saved = localStorage.getItem('bets_data');
    return saved ? JSON.parse(saved) : INITIAL_BETS;
  });

  const [rouletteItems, setRouletteItems] = useState<RouletteItem[]>(() => {
    const saved = localStorage.getItem('roulette_data');
    return saved ? JSON.parse(saved) : INITIAL_ROULETTE_ITEMS;
  });

  // UI Navigation & Filters
  const [currentTab, setCurrentTab] = useState<'bets' | 'categories' | 'games' | 'leaderboard'>('bets');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'resolved'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isMuted, setIsMuted] = useState(false);

  // Modals
  const [isNewBetOpen, setIsNewBetOpen] = useState(false);
  const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);
  const [isZipModalOpen, setIsZipModalOpen] = useState(false);
  const [resolvingBet, setResolvingBet] = useState<Bet | null>(null);
  const [preselectedCategoryId, setPreselectedCategoryId] = useState<string | undefined>(undefined);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('panas_data', JSON.stringify(panas));
  }, [panas]);

  useEffect(() => {
    localStorage.setItem('categories_data', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('bets_data', JSON.stringify(bets));
  }, [bets]);

  useEffect(() => {
    localStorage.setItem('roulette_data', JSON.stringify(rouletteItems));
  }, [rouletteItems]);

  // Handlers for Categories
  const handleAddCategory = (newCat: Omit<BetCategory, 'id' | 'createdAt'>) => {
    const created: BetCategory = {
      ...newCat,
      id: `cat-${Date.now()}`,
      createdAt: Date.now(),
    };
    setCategories((prev) => [created, ...prev]);
  };

  const handleDeleteCategory = (categoryId: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== categoryId));
    if (selectedCategoryFilter === categoryId) {
      setSelectedCategoryFilter('all');
    }
  };

  // Handlers for Bets
  const handleCreateBet = (newBet: Omit<Bet, 'id' | 'createdAt'>) => {
    const created: Bet = {
      ...newBet,
      id: `bet-${Date.now()}`,
      createdAt: Date.now(),
    };
    setBets((prev) => [created, ...prev]);
  };

  const handleDeleteBet = (betId: string) => {
    setBets((prev) => prev.filter((b) => b.id !== betId));
  };

  const handleConfirmResolve = (
    betId: string,
    winnerId: string,
    loserId: string,
    proofNote?: string
  ) => {
    setBets((prev) =>
      prev.map((b) => {
        if (b.id !== betId) return b;
        return {
          ...b,
          status: 'resolved',
          winnerPanaId: winnerId,
          loserPanaId: loserId,
          proofNote,
          resolvedAt: Date.now(),
        };
      })
    );

    // Update Panas statistics (victories, losses, pending debts)
    setPanas((prev) =>
      prev.map((p) => {
        if (p.id === winnerId) {
          return { ...p, victories: p.victories + 1 };
        }
        if (p.id === loserId) {
          return { ...p, losses: p.losses + 1, pendingDebts: p.pendingDebts + 1 };
        }
        return p;
      })
    );
  };

  const handleMarkDebtPaid = (betId: string) => {
    const targetBet = bets.find((b) => b.id === betId);
    if (!targetBet) return;

    setBets((prev) =>
      prev.map((b) => {
        if (b.id !== betId) return b;
        const currentNote = b.proofNote || '';
        return {
          ...b,
          proofNote: currentNote.includes('[PAGADO]')
            ? currentNote
            : `${currentNote} [PAGADO CON HONOR]`.trim(),
        };
      })
    );

    if (targetBet.loserPanaId) {
      setPanas((prev) =>
        prev.map((p) => {
          if (p.id === targetBet.loserPanaId) {
            return { ...p, pendingDebts: Math.max(0, p.pendingDebts - 1) };
          }
          return p;
        })
      );
    }
  };

  const handleAddPana = (newPana: Omit<Pana, 'id' | 'victories' | 'losses' | 'pendingDebts'>) => {
    const created: Pana = {
      ...newPana,
      id: `pana-${Date.now()}`,
      victories: 0,
      losses: 0,
      pendingDebts: 0,
    };
    setPanas((prev) => [...prev, created]);
  };

  // Filtered bets
  const filteredBets = bets.filter((bet) => {
    // Category filter
    if (selectedCategoryFilter !== 'all' && bet.categoryId !== selectedCategoryFilter) {
      return false;
    }
    // Status filter
    if (statusFilter === 'active' && bet.status !== 'active') return false;
    if (statusFilter === 'resolved' && bet.status !== 'resolved') return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = bet.title.toLowerCase().includes(q);
      const matchStake = bet.stake.toLowerCase().includes(q);
      const matchDesc = bet.description?.toLowerCase().includes(q);
      return matchTitle || matchStake || matchDesc;
    }

    return true;
  });

  const activeBetsCount = bets.filter((b) => b.status === 'active').length;
  const customCategoriesCount = categories.filter((c) => c.isCustom).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500 selection:text-black">
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onOpenNewBet={() => {
          setPreselectedCategoryId(undefined);
          setIsNewBetOpen(true);
        }}
        onOpenCategories={() => setIsCategoryManagerOpen(true)}
        onOpenZipModal={() => setIsZipModalOpen(true)}
        isMuted={isMuted}
        onToggleMute={() => setIsMuted(!isMuted)}
        activeBetsCount={activeBetsCount}
        customCategoriesCount={customCategoriesCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* ================= TAB 1: MURO DE APUESTAS ================= */}
        {currentTab === 'bets' && (
          <div className="space-y-6">
            {/* Category Filter Bar & Search */}
            <div className="space-y-3">
              {/* Category Segmented Scrollable Control */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1.5 no-scrollbar">
                <button
                  onClick={() => {
                    playClickSound();
                    setSelectedCategoryFilter('all');
                  }}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                    selectedCategoryFilter === 'all'
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span>🔥</span>
                  <span>Todas las Apuestas</span>
                  <span className="text-[10px] opacity-80 font-mono">({bets.length})</span>
                </button>

                {categories.map((cat) => {
                  const isSelected = selectedCategoryFilter === cat.id;
                  const count = bets.filter((b) => b.categoryId === cat.id).length;

                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        playClickSound();
                        setSelectedCategoryFilter(cat.id);
                      }}
                      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap border ${
                        isSelected
                          ? 'border-white bg-slate-800 text-white shadow-md'
                          : 'border-slate-800/80 bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800/60'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      <span>{cat.name}</span>
                      {count > 0 && (
                        <span
                          className="w-1.5 h-1.5 rounded-full"
                          style={{ backgroundColor: cat.color }}
                        />
                      )}
                      <span className="text-[10px] opacity-70 font-mono">({count})</span>
                    </button>
                  );
                })}

                {/* Instant Create Custom Category Button */}
                <button
                  onClick={() => {
                    playClickSound();
                    setIsCategoryManagerOpen(true);
                  }}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 transition-colors whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Personalizar Categorías</span>
                </button>
              </div>

              {/* Status and Search filters bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                {/* Search */}
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar apuestas por reto, pana o castigo..."
                    className="w-full pl-9 pr-3 py-2 bg-slate-900/90 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Status Segmented Buttons */}
                <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl self-stretch sm:self-auto">
                  <button
                    onClick={() => {
                      playClickSound();
                      setStatusFilter('all');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      statusFilter === 'all'
                        ? 'bg-slate-800 text-white font-bold shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Todas ({bets.length})
                  </button>
                  <button
                    onClick={() => {
                      playClickSound();
                      setStatusFilter('active');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      statusFilter === 'active'
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    En Juego ({bets.filter((b) => b.status === 'active').length})
                  </button>
                  <button
                    onClick={() => {
                      playClickSound();
                      setStatusFilter('resolved');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      statusFilter === 'resolved'
                        ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Resueltas ({bets.filter((b) => b.status === 'resolved').length})
                  </button>
                </div>
              </div>
            </div>

            {/* Bets Grid */}
            {filteredBets.length === 0 ? (
              <div className="text-center py-16 px-4 bg-slate-900/40 rounded-2xl border border-dashed border-slate-800">
                <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-3xl mx-auto mb-3">
                  🎲
                </div>
                <h3 className="text-base font-bold text-white">No hay apuestas en esta vista</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  {searchQuery
                    ? 'No se encontraron resultados para tu búsqueda. Intenta con otros términos.'
                    : 'Crea una nueva apuesta con tus amigos o prueba otra categoría.'}
                </p>
                <div className="mt-5 flex items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      playClickSound();
                      setIsNewBetOpen(true);
                    }}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all"
                  >
                    + Lanzar Apuesta
                  </button>
                  {selectedCategoryFilter !== 'all' && (
                    <button
                      onClick={() => setSelectedCategoryFilter('all')}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl"
                    >
                      Ver Todas las Categorías
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredBets.map((bet) => {
                  const category = categories.find((c) => c.id === bet.categoryId);
                  return (
                    <BetCard
                      key={bet.id}
                      bet={bet}
                      category={category}
                      panas={panas}
                      onResolve={(b) => setResolvingBet(b)}
                      onDelete={handleDeleteBet}
                      onMarkDebtPaid={handleMarkDebtPaid}
                    />
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 2: CATEGORÍAS PERSONALIZADAS ================= */}
        {currentTab === 'categories' && (
          <div className="space-y-6">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Tag className="w-5 h-5 text-amber-400" />
                  <h2 className="text-lg font-bold text-white">Sistema de Categorización de Apuestas</h2>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Organiza y clasifica tus apuestas entre panas. Crea categorías temáticas ilimitadas.
                </p>
              </div>

              <button
                onClick={() => {
                  playClickSound();
                  setIsCategoryManagerOpen(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition-all self-start sm:self-auto"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                Crear Categoría Personalizada
              </button>
            </div>

            {/* Categories cards grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((cat) => {
                const totalCatBets = bets.filter((b) => b.categoryId === cat.id);
                const activeCatBets = totalCatBets.filter((b) => b.status === 'active');
                const resolvedCatBets = totalCatBets.filter((b) => b.status === 'resolved');

                return (
                  <div
                    key={cat.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <span
                            className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner"
                            style={{
                              backgroundColor: `${cat.color}15`,
                              border: `1px solid ${cat.color}40`,
                            }}
                          >
                            {cat.icon}
                          </span>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h3 className="font-bold text-white text-base">{cat.name}</h3>
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono">
                              {cat.isCustom ? 'Personalizada por el grupo' : 'Categoría Estándar'}
                            </span>
                          </div>
                        </div>

                        {cat.isCustom && (
                          <button
                            onClick={() => {
                              if (confirm(`¿Eliminar la categoría "${cat.name}"?`)) {
                                handleDeleteCategory(cat.id);
                              }
                            }}
                            className="p-2 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Eliminar categoría personalizada"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>

                      <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                        {cat.description}
                      </p>

                      {/* Metrics unboxed */}
                      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-3 text-xs text-slate-400">
                        <span>Total: <strong className="text-white">{totalCatBets.length}</strong></span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span>Activas: <strong className="text-amber-400">{activeCatBets.length}</strong></span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span>Resueltas: <strong className="text-emerald-400">{resolvedCatBets.length}</strong></span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2">
                      <button
                        onClick={() => {
                          playClickSound();
                          setSelectedCategoryFilter(cat.id);
                          setCurrentTab('bets');
                        }}
                        className="flex-1 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition-colors text-center"
                      >
                        Ver Apuestas
                      </button>
                      <button
                        onClick={() => {
                          playClickSound();
                          setPreselectedCategoryId(cat.id);
                          setIsNewBetOpen(true);
                        }}
                        className="flex-1 py-2 text-xs font-bold bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 rounded-xl transition-colors text-center"
                      >
                        + Apostar Aquí
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ================= TAB 3: RULETA & MINIJUEGOS ================= */}
        {currentTab === 'games' && (
          <div className="space-y-8">
            <div className="pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <RotateCw className="w-5 h-5 text-amber-400" />
                <h2 className="text-lg font-bold text-white">Centro de Juegos & Resolución al Azar</h2>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Usa la Ruleta de Castigos, el Duelo de Dados o Cara o Cruz para resolver empates y fijar prendas
              </p>
            </div>

            {/* Roulette Section */}
            <section>
              <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                La Ruleta de Castigos Oficial
              </h3>
              <RouletteGame
                items={rouletteItems}
                onUpdateItems={setRouletteItems}
              />
            </section>

            {/* Minigames Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Dice Game */}
              <section>
                <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-400 mb-3 flex items-center gap-2">
                  <Dices className="w-4 h-4" />
                  Duelo de Dados 1v1
                </h3>
                <DiceGame panas={panas} />
              </section>

              {/* Coin Game */}
              <section>
                <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 mb-3 flex items-center gap-2">
                  <Flame className="w-4 h-4" />
                  Moneda de la Suerte
                </h3>
                <CoinGame />
              </section>
            </div>
          </div>
        )}

        {/* ================= TAB 4: TABLA DE HONOR & DEUDAS ================= */}
        {currentTab === 'leaderboard' && (
          <PanasLeaderboard
            panas={panas}
            bets={bets}
            onAddPana={handleAddPana}
            onPayDebt={handleMarkDebtPaid}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400">APUESTA ENTRE PANAS</span>
            <span>·</span>
            <span>Las deudas entre amigos se pagan con honor 🍻</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsZipModalOpen(true)}
              className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
            >
              <FileArchive className="w-3.5 h-3.5" />
              Descargar App en ZIP
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <CreateBetModal
        isOpen={isNewBetOpen}
        onClose={() => setIsNewBetOpen(false)}
        categories={categories}
        panas={panas}
        onCreateBet={handleCreateBet}
        onOpenCategoryManager={() => {
          setIsNewBetOpen(false);
          setIsCategoryManagerOpen(true);
        }}
        defaultCategoryId={preselectedCategoryId}
      />

      <CategoryManagerModal
        isOpen={isCategoryManagerOpen}
        onClose={() => setIsCategoryManagerOpen(false)}
        categories={categories}
        bets={bets}
        onAddCategory={handleAddCategory}
        onDeleteCategory={handleDeleteCategory}
      />

      <ResolveBetModal
        isOpen={!!resolvingBet}
        onClose={() => setResolvingBet(null)}
        bet={resolvingBet}
        panas={panas}
        rouletteItems={rouletteItems}
        onConfirmResolve={handleConfirmResolve}
      />

      <ZipExportModal
        isOpen={isZipModalOpen}
        onClose={() => setIsZipModalOpen(false)}
        categories={categories}
        bets={bets}
        panas={panas}
      />
    </div>
  );
}
