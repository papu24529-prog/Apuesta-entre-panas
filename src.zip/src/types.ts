export interface Pana {
  id: string;
  name: string;
  nickname: string;
  avatar: string; // emoji or avatar url
  color: string;
  victories: number;
  losses: number;
  pendingDebts: number;
}

export interface BetCategory {
  id: string;
  name: string;
  slug: string;
  icon: string; // emoji or icon identifier
  color: string; // tailwind color token or hex
  bgGradient: string;
  description: string;
  isCustom: boolean;
  createdAt: number;
}

export interface BetParticipant {
  panaId: string;
  prediction: string;
  status: 'pending' | 'accepted' | 'declined';
  hasPaidDebt?: boolean;
}

export interface Bet {
  id: string;
  title: string;
  description?: string;
  categoryId: string;
  stake: string; // e.g. "Cena de tacos", "6 Cervezas frías", "50 flexiones"
  creatorPanaId: string;
  participants: BetParticipant[];
  status: 'open' | 'active' | 'resolved' | 'cancelled';
  resolutionMethod: 'manual' | 'roulette' | 'dice' | 'voting';
  winnerPanaId?: string;
  loserPanaId?: string;
  dueDate?: string;
  proofNote?: string;
  proofImageUrl?: string;
  createdAt: number;
  resolvedAt?: number;
  votes?: Record<string, string>; // voterPanaId -> winnerPanaId
}

export interface RouletteItem {
  id: string;
  text: string;
  emoji: string;
  color: string;
}
