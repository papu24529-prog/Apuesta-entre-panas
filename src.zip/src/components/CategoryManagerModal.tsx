import React, { useState } from 'react';
import { X, Plus, Trash2, Tag, Check, Sparkles } from 'lucide-react';
import { BetCategory, Bet } from '../types';
import { playClickSound } from '../utils/audio';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: BetCategory[];
  bets: Bet[];
  onAddCategory: (category: Omit<BetCategory, 'id' | 'createdAt'>) => void;
  onDeleteCategory: (categoryId: string) => void;
}

const PRESET_EMOJIS = [
  '⚽', '🎮', '🍻', '🍔', '🏋️', '🤪', '🎲', '🏎️', 
  '🏀', '🥊', '🍕', '🌮', '🎸', '🏖️', '🎬', '📚', 
  '🚗', '💰', '🧠', '👑', '🔥', '🎯', '🚀', '⚡'
];

const PRESET_COLORS = [
  { name: 'Esmeralda', hex: '#10b981', gradient: 'from-emerald-900/40 via-emerald-950/20 to-slate-900' },
  { name: 'Ámbar', hex: '#f59e0b', gradient: 'from-amber-900/40 via-amber-950/20 to-slate-900' },
  { name: 'Índigo', hex: '#6366f1', gradient: 'from-indigo-900/40 via-indigo-950/20 to-slate-900' },
  { name: 'Naranja', hex: '#f97316', gradient: 'from-orange-900/40 via-orange-950/20 to-slate-900' },
  { name: 'Rosa / Gym', hex: '#ec4899', gradient: 'from-pink-900/40 via-pink-950/20 to-slate-900' },
  { name: 'Púrpura', hex: '#a855f7', gradient: 'from-purple-900/40 via-purple-950/20 to-slate-900' },
  { name: 'Cian', hex: '#06b6d4', gradient: 'from-cyan-900/40 via-cyan-950/20 to-slate-900' },
  { name: 'Rojo Pasión', hex: '#ef4444', gradient: 'from-red-900/40 via-red-950/20 to-slate-900' },
  { name: 'Dorado Real', hex: '#eab308', gradient: 'from-yellow-900/40 via-yellow-950/20 to-slate-900' },
];

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  categories,
  bets,
  onAddCategory,
  onDeleteCategory,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('🔥');
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Por favor escribe un nombre para la categoría');
      return;
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    
    onAddCategory({
      name: name.trim(),
      slug,
      icon: selectedEmoji,
      color: selectedColor.hex,
      bgGradient: selectedColor.gradient,
      description: description.trim() || 'Categoría personalizada para retos y apuestas entre panas.',
      isCustom: true,
    });

    playClickSound();
    setName('');
    setDescription('');
    setIsCreating(false);
    setError('');
  };

  const getBetCount = (categoryId: string) => {
    return bets.filter((b) => b.categoryId === categoryId).length;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Sistema de Categorías</h2>
              <p className="text-xs text-slate-400">Crea y administra categorías personalizadas para tus apuestas</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Action button to create new */}
          {!isCreating ? (
            <div className="flex items-center justify-between p-4 rounded-xl border border-dashed border-slate-700 bg-slate-800/40 hover:border-amber-500/50 transition-colors">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">¿Quieres una categoría única para tu grupo?</h3>
                <p className="text-xs text-slate-400 mt-0.5">Define retos de pádel, series, viajes, oficina o anécdotas de panas.</p>
              </div>
              <button
                onClick={() => {
                  playClickSound();
                  setIsCreating(true);
                }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/10 transition-all hover:scale-[1.02]"
              >
                <Plus className="w-4 h-4" />
                Nueva Categoría
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-5 rounded-xl border border-amber-500/30 bg-amber-500/5 space-y-4 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Crear Nueva Categoría Personalizada
                </span>
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancelar
                </button>
              </div>

              {error && (
                <p className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 rounded-lg">
                  {error}
                </p>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Nombre de la Categoría</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      setError('');
                    }}
                    placeholder="Ej. Pádel de los Miércoles, Viaje a la Playa..."
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Descripción corta</label>
                  <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="De qué se tratan las apuestas aquí..."
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Emoji Selector */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">Icono / Emoji representativo</label>
                <div className="flex flex-wrap gap-2 p-2 bg-slate-800/80 rounded-xl border border-slate-700/60 max-h-28 overflow-y-auto">
                  {PRESET_EMOJIS.map((emoji) => (
                    <button
                      type="button"
                      key={emoji}
                      onClick={() => setSelectedEmoji(emoji)}
                      className={`w-9 h-9 text-lg rounded-lg flex items-center justify-center transition-all ${
                        selectedEmoji === emoji
                          ? 'bg-amber-500/30 border-2 border-amber-400 scale-110 shadow-sm'
                          : 'bg-slate-700/50 hover:bg-slate-700 border border-slate-600/50'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Selector */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">Color Temático</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {PRESET_COLORS.map((col) => (
                    <button
                      type="button"
                      key={col.name}
                      onClick={() => setSelectedColor(col)}
                      className={`flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                        selectedColor.name === col.name
                          ? 'border-white bg-slate-800 shadow-md ring-1 ring-white/50'
                          : 'border-slate-800 bg-slate-800/40 hover:bg-slate-800'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full flex-shrink-0"
                        style={{ backgroundColor: col.hex }}
                      />
                      <span className="text-[11px] text-slate-300 truncate">{col.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Preview */}
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl p-2 rounded-xl bg-slate-800 border border-slate-700">{selectedEmoji}</span>
                  <div>
                    <span className="text-xs text-slate-500">Vista previa</span>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      {name.trim() || 'Nombre de la Categoría'}
                      <span
                        className="w-2 h-2 rounded-full inline-block"
                        style={{ backgroundColor: selectedColor.hex }}
                      />
                    </h4>
                    <p className="text-xs text-slate-400">{description.trim() || 'Descripción de ejemplo...'}</p>
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Guardar Categoría
                </button>
              </div>
            </form>
          )}

          {/* List of existing categories */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Categorías Disponibles ({categories.length})
              </h3>
              <span className="text-xs text-slate-500">
                {categories.filter((c) => c.isCustom).length} personalizadas
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {categories.map((cat) => {
                const count = getBetCount(cat.id);
                return (
                  <div
                    key={cat.id}
                    className="p-3.5 bg-slate-800/40 border border-slate-800 hover:border-slate-700 rounded-xl flex items-start justify-between transition-colors group"
                  >
                    <div className="flex items-start gap-3">
                      <span
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                        style={{
                          backgroundColor: `${cat.color}15`,
                          border: `1px solid ${cat.color}40`,
                        }}
                      >
                        {cat.icon}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-semibold text-white">{cat.name}</h4>
                          {cat.isCustom && (
                            <span className="text-[10px] text-amber-400 font-medium">Personalizada</span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">{cat.description}</p>
                        <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5">
                          <span>{count} {count === 1 ? 'apuesta' : 'apuestas'}</span>
                        </div>
                      </div>
                    </div>

                    {cat.isCustom && (
                      <button
                        onClick={() => {
                          if (confirm(`¿Eliminar la categoría personalizada "${cat.name}"? Las apuestas existentes mantendrán su historial.`)) {
                            playClickSound();
                            onDeleteCategory(cat.id);
                          }
                        }}
                        title="Eliminar categoría personalizada"
                        className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors opacity-80 group-hover:opacity-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end">
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
