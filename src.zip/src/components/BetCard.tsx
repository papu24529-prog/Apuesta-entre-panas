import React from 'react';
import { Trophy, Clock, Skull, CheckCircle2, RotateCw, Dices, Users2, Trash2 } from 'lucide-react';
import { Bet, BetCategory, Pana } from '../types';
import { playClickSound } from '../utils/audio';

interface BetCardProps {
  bet: Bet;
  category?: BetCategory;
  panas: Pana[];
  onResolve: (bet: Bet) => void;
  onDelete: (betId: string) => void;
  onMarkDebtPaid: (betId: string) => void;
}

export const BetCard: React.FC<BetCardProps> = ({
  bet,
  category,
  panas,
  onResolve,
  onDelete,
  onMarkDebtPaid,
}) => {
  const getPana = (id?: string) => panas.find((p) => p.id === id);

  const creator = getPana(bet.creatorPanaId);
  const winner = getPana(bet.winnerPanaId);
  const loser = getPana(bet.loserPanaId);

  const isResolved = bet.status === 'resolved';

  const categoryColor = category?.color || '#f59e0b';

  return (
    <div className="group relative bg-slate-900/90 border border-slate-800/90 hover:border-slate-700/80 rounded-2xl p-5 shadow-lg transition-all flex flex-col justify-between overflow-hidden">
      {/* Category accent bar at the top */}
      <div
        className="absolute top-0 left-0 right-0 h-1 transition-opacity opacity-75 group-hover:opacity-100"
        style={{ backgroundColor: categoryColor }}
      />

      <div>
        {/* Unboxed Metadata (Frontend Design Constitution: Zero-pill discipline) */}
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2.5">
          <div className="flex items-center gap-2">
            <span className="text-base">{category?.icon || '🔥'}</span>
            <span className="font-semibold text-slate-300">{category?.name || 'Apuesta General'}</span>
            {category?.isCustom && (
              <>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-amber-400/90 font-medium text-[11px]">Personalizada</span>
              </>
            )}
            {bet.dueDate && (
              <>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="flex items-center gap-1 text-slate-400 text-[11px]">
                  <Clock className="w-3 h-3 text-slate-500" />
                  {bet.dueDate}
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isResolved ? (
              <span className="text-emerald-400 font-bold text-xs flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Resuelta
              </span>
            ) : (
              <span className="text-amber-400 font-semibold text-xs flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                En Juego
              </span>
            )}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-white leading-snug group-hover:text-amber-300 transition-colors">
          {bet.title}
        </h3>

        {bet.description && (
          <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
            {bet.description}
          </p>
        )}

        {/* Stake Box ("El Castigo / Lo que se Paga") */}
        <div className="mt-3.5 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-start gap-2.5">
          <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 flex-shrink-0">
            <Trophy className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400/80 block">
              El Castigo / La Paga
            </span>
            <span className="text-xs font-semibold text-slate-200">
              {bet.stake}
            </span>
          </div>
        </div>

        {/* Participants Duel Display */}
        <div className="mt-3.5 pt-3 border-t border-slate-800/60">
          <div className="text-[11px] font-semibold text-slate-400 mb-2">
            Panas en Duelo:
          </div>
          <div className="space-y-2">
            {bet.participants.map((part) => {
              const p = getPana(part.panaId);
              if (!p) return null;
              const isWinner = isResolved && bet.winnerPanaId === p.id;
              const isLoser = isResolved && bet.loserPanaId === p.id;

              return (
                <div
                  key={p.id}
                  className={`flex items-center justify-between p-2 rounded-lg text-xs transition-colors ${
                    isWinner
                      ? 'bg-emerald-950/30 border border-emerald-500/30 text-emerald-300'
                      : isLoser
                      ? 'bg-rose-950/20 border border-rose-500/30 text-rose-300'
                      : 'bg-slate-800/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{p.avatar}</span>
                    <span className="font-semibold text-white">{p.name}</span>
                    <span className="text-[11px] text-slate-400 italic">"{p.nickname}"</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px] truncate max-w-[140px]">
                      {part.prediction}
                    </span>
                    {isWinner && (
                      <span className="font-bold text-emerald-400 flex items-center gap-0.5 text-[11px]">
                        <Trophy className="w-3 h-3" /> Ganador
                      </span>
                    )}
                    {isLoser && (
                      <span className="font-bold text-rose-400 flex items-center gap-0.5 text-[11px]">
                        <Skull className="w-3 h-3" /> Paga el castigo
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Resolved Note / Proof if any */}
        {isResolved && bet.proofNote && (
          <div className="mt-3 p-2.5 rounded-lg bg-purple-950/20 border border-purple-500/20 text-xs text-purple-200">
            <span className="font-semibold text-purple-300">Nota del castigo: </span>
            {bet.proofNote}
          </div>
        )}
      </div>

      {/* Card Action Buttons */}
      <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between gap-2">
        <button
          onClick={() => {
            if (confirm(`¿Eliminar la apuesta "${bet.title}"?`)) {
              playClickSound();
              onDelete(bet.id);
            }
          }}
          className="p-2 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
          title="Eliminar apuesta"
        >
          <Trash2 className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2">
          {!isResolved ? (
            <button
              onClick={() => {
                playClickSound();
                onResolve(bet);
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all hover:scale-[1.02]"
            >
              {bet.resolutionMethod === 'roulette' && <RotateCw className="w-3.5 h-3.5" />}
              {bet.resolutionMethod === 'dice' && <Dices className="w-3.5 h-3.5" />}
              {bet.resolutionMethod === 'voting' && <Users2 className="w-3.5 h-3.5" />}
              {bet.resolutionMethod === 'manual' && <Trophy className="w-3.5 h-3.5" />}
              Resolver Apuesta
            </button>
          ) : (
            <button
              onClick={() => {
                playClickSound();
                onMarkDebtPaid(bet.id);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Castigo Cumplido
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
