import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Dices, Trophy, RotateCcw } from 'lucide-react';
import { Pana } from '../types';
import { playClickSound, playDiceShakeSound, playWinSound } from '../utils/audio';

interface DiceGameProps {
  panas: Pana[];
  onWinnerDecided?: (winnerId: string, loserId: string) => void;
  defaultPana1Id?: string;
  defaultPana2Id?: string;
}

export const DiceGame: React.FC<DiceGameProps> = ({
  panas,
  onWinnerDecided,
  defaultPana1Id,
  defaultPana2Id,
}) => {
  const [pana1Id, setPana1Id] = useState(defaultPana1Id || panas[0]?.id || '');
  const [pana2Id, setPana2Id] = useState(defaultPana2Id || panas[1]?.id || '');
  const [isRolling, setIsRolling] = useState(false);
  const [dice1, setDice1] = useState(6);
  const [dice2, setDice2] = useState(6);
  const [score1, setScore1] = useState(0);
  const [score2, setScore2] = useState(0);
  const [roundWinner, setRoundWinner] = useState<string | null>(null);

  const p1 = panas.find((p) => p.id === pana1Id);
  const p2 = panas.find((p) => p.id === pana2Id);

  const rollDice = () => {
    if (isRolling || !p1 || !p2) return;
    setIsRolling(true);
    setRoundWinner(null);
    playClickSound();

    let rollCount = 0;
    const interval = setInterval(() => {
      setDice1(Math.floor(Math.random() * 6) + 1);
      setDice2(Math.floor(Math.random() * 6) + 1);
      playDiceShakeSound();
      rollCount++;

      if (rollCount > 10) {
        clearInterval(interval);
        const finalD1 = Math.floor(Math.random() * 6) + 1;
        const finalD2 = Math.floor(Math.random() * 6) + 1;
        setDice1(finalD1);
        setDice2(finalD2);
        setIsRolling(false);

        if (finalD1 > finalD2) {
          setScore1((prev) => prev + 1);
          setRoundWinner(p1.id);
          playWinSound();
          confetti({ particleCount: 50, spread: 60 });
          if (onWinnerDecided) onWinnerDecided(p1.id, p2.id);
        } else if (finalD2 > finalD1) {
          setScore2((prev) => prev + 1);
          setRoundWinner(p2.id);
          playWinSound();
          confetti({ particleCount: 50, spread: 60 });
          if (onWinnerDecided) onWinnerDecided(p2.id, p1.id);
        } else {
          setRoundWinner('tie');
        }
      }
    }, 80);
  };

  const resetMatch = () => {
    setScore1(0);
    setScore2(0);
    setRoundWinner(null);
    setDice1(6);
    setDice2(6);
    playClickSound();
  };

  // Render a retro dice face
  const renderDice = (val: number) => {
    const dots: Record<number, number[]> = {
      1: [4],
      2: [0, 8],
      3: [0, 4, 8],
      4: [0, 2, 6, 8],
      5: [0, 2, 4, 6, 8],
      6: [0, 2, 3, 5, 6, 8],
    };
    const activeDots = dots[val] || [4];

    return (
      <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-2xl shadow-xl border-4 border-slate-300 p-3 grid grid-cols-3 grid-rows-3 gap-1 transform transition-transform hover:scale-105">
        {Array.from({ length: 9 }).map((_, idx) => (
          <div key={idx} className="flex items-center justify-center">
            {activeDots.includes(idx) && (
              <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 bg-slate-900 rounded-full shadow-inner" />
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Dices className="w-5 h-5 text-indigo-400" />
          <h3 className="text-base font-bold text-white">Duelo de Dados 1v1</h3>
        </div>
        <button
          onClick={resetMatch}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reiniciar Marcador
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        {/* Pana 1 */}
        <div className="flex flex-col items-center p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
          <select
            value={pana1Id}
            onChange={(e) => setPana1Id(e.target.value)}
            className="mb-3 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-white focus:outline-none focus:border-indigo-500"
          >
            {panas.map((p) => (
              <option key={p.id} value={p.id} disabled={p.id === pana2Id}>
                {p.avatar} {p.name} "{p.nickname}"
              </option>
            ))}
          </select>

          <div className="text-3xl mb-3">{p1?.avatar || '👤'}</div>
          <div className="font-bold text-white text-base">{p1?.name}</div>
          <div className="text-xs text-indigo-400 font-semibold mb-4">Victorias: {score1}</div>

          <div className={`transition-transform ${isRolling ? 'animate-bounce' : ''}`}>
            {renderDice(dice1)}
          </div>
        </div>

        {/* Pana 2 */}
        <div className="flex flex-col items-center p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
          <select
            value={pana2Id}
            onChange={(e) => setPana2Id(e.target.value)}
            className="mb-3 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-white focus:outline-none focus:border-indigo-500"
          >
            {panas.map((p) => (
              <option key={p.id} value={p.id} disabled={p.id === pana1Id}>
                {p.avatar} {p.name} "{p.nickname}"
              </option>
            ))}
          </select>

          <div className="text-3xl mb-3">{p2?.avatar || '👤'}</div>
          <div className="font-bold text-white text-base">{p2?.name}</div>
          <div className="text-xs text-indigo-400 font-semibold mb-4">Victorias: {score2}</div>

          <div className={`transition-transform ${isRolling ? 'animate-bounce' : ''}`}>
            {renderDice(dice2)}
          </div>
        </div>
      </div>

      {/* Central Roll Button & Status */}
      <div className="mt-8 flex flex-col items-center">
        <button
          onClick={rollDice}
          disabled={isRolling || !p1 || !p2}
          className={`px-8 py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center gap-2 shadow-xl transition-all ${
            isRolling
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-indigo-500 via-indigo-600 to-indigo-500 hover:scale-105 text-white shadow-indigo-500/25 active:scale-95'
          }`}
        >
          <Dices className={`w-5 h-5 ${isRolling ? 'animate-spin' : ''}`} />
          {isRolling ? '¡Lanzando Dados...!' : '¡Lanzar Dados 1v1!'}
        </button>

        {roundWinner && (
          <div className="mt-4 p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-center animate-in zoom-in-95">
            {roundWinner === 'tie' ? (
              <span className="text-sm font-bold text-amber-400">¡Empate! Vuelvan a tirar 🎲</span>
            ) : (
              <div className="flex items-center gap-2 text-indigo-300 font-bold text-sm">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>
                  ¡Ganó {roundWinner === p1?.id ? p1?.name : p2?.name}! ({dice1} vs {dice2})
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
