import React, { useState } from 'react';
import { X, FileArchive, Download, Check, Sparkles, FolderDown, Terminal, Info } from 'lucide-react';
import { Bet, BetCategory, Pana } from '../types';
import { exportProjectToZip } from '../utils/zipExporter';
import { playClickSound, playWinSound } from '../utils/audio';

interface ZipExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: BetCategory[];
  bets: Bet[];
  panas: Pana[];
}

export const ZipExportModal: React.FC<ZipExportModalProps> = ({
  isOpen,
  onClose,
  categories,
  bets,
  panas,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    try {
      setIsExporting(true);
      playClickSound();

      await exportProjectToZip({
        categories,
        bets,
        panas,
      });

      playWinSound();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Error generating zip:', err);
      alert('Hubo un error al empaquetar el archivo ZIP.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadStaticZip = () => {
    playClickSound();
    const link = document.createElement('a');
    link.href = '/apuesta-entre-panas.zip';
    link.download = 'apuesta-entre-panas.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <FileArchive className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Descargar App en ZIP</h2>
              <p className="text-xs text-slate-400">Exporta el proyecto completo de "Apuesta Entre Panas"</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3">
            <Info className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300 leading-relaxed">
              <strong className="text-white block mb-0.5">¿Qué incluye el archivo .ZIP descargado?</strong>
              Todo el código fuente completo listo para producción (React 19, TypeScript, Tailwind CSS, Vite, ruleta interactiva, sistema de categorías personalizadas, y el respaldo de tus apuestas actuales).
            </div>
          </div>

          {/* Primary Action Button */}
          <div className="space-y-3">
            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className={`w-full py-4 px-6 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-3 shadow-xl transition-all ${
                downloadSuccess
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-500 text-slate-950 hover:scale-[1.02] shadow-amber-500/20 active:scale-98'
              }`}
            >
              {isExporting ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin" />
                  <span>Empaquetando archivos ZIP...</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <Check className="w-5 h-5" />
                  <span>¡ZIP Descargado con Éxito!</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Descargar apuesta-entre-panas.zip</span>
                </>
              )}
            </button>

            {/* Alternative static link */}
            <div className="text-center">
              <button
                onClick={handleDownloadStaticZip}
                className="text-xs text-slate-400 hover:text-amber-400 underline transition-colors"
              >
                O descarga el paquete directo del servidor (.zip estático)
              </button>
            </div>
          </div>

          {/* How to run instructions */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
              Pasos para correrlo en tu máquina:
            </span>
            <div className="space-y-1.5 font-mono text-xs text-slate-300">
              <p className="text-slate-400">1. Descomprime el archivo <code className="text-amber-400">.zip</code></p>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800/80">
                <p className="text-slate-400 text-[11px]"># En tu terminal dentro de la carpeta:</p>
                <p className="text-emerald-400 font-bold">npm install</p>
                <p className="text-emerald-400 font-bold">npm run dev</p>
              </div>
              <p className="text-slate-400">3. Abre en tu navegador: <code className="text-indigo-400">http://localhost:3000</code></p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end">
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
