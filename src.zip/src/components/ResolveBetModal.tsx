import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { X, Trophy, Skull, CheckCircle2, RotateCw, Dices, Users2 } from 'lucide-react';
import { Bet, Pana, RouletteItem } from '../types';
import { playClickSound, playWinSound } from '../utils/audio';
import { RouletteGame } from './RouletteGame';
import { DiceGame } from './DiceGame';

interface ResolveBetModalProps {
  isOpen: boolean;
  onClose: () => void;
  bet: Bet | null;
  panas: Pana[];
  rouletteItems: RouletteItem[];
  onConfirmResolve: (
    betId: string,
    winnerId: string,
    loserId: string,
    proofNote?: string
  ) => void;
}

export const ResolveBetModal: React.FC<ResolveBetModalProps> = ({
  isOpen,
  onClose,
  bet,
  panas,
  rouletteItems,
  onConfirmResolve,
}) => {
  if (!isOpen || !bet) return null;

  const [activeTab, setActiveTab] = useState<'decision' | 'roulette' | 'dice'>('decision');
  const [winnerId, setWinnerId] = useState(bet.participants[0]?.panaId || '');
  const [loserId, setLoserId] = useState(bet.participants[1]?.panaId || '');
  const [proofNote, setProofNote] = useState('');

  const getPana = (id: string) => panas.find((p) => p.id === id);

  const handleResolve = () => {
    if (!winnerId || !loserId || winnerId === loserId) {
      alert('Debes seleccionar un ganador y un perdedor diferentes');
      return;
    }

    playClickSound();
    playWinSound();
    confetti({ particleCount: 80, spread: 70 });

    onConfirmResolve(bet.id, winnerId, loserId, proofNote.trim() || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Resolver Apuesta</h2>
              <p className="text-xs text-slate-400">{bet.title}</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Resolution Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 p-2 gap-1">
          <button
            onClick={() => setActiveTab('decision')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'decision'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Declarar Ganador
          </button>
          <button
            onClick={() => setActiveTab('roulette')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'roulette'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <RotateCw className="w-3.5 h-3.5" />
            Girar Ruleta
          </button>
          <button
            onClick={() => setActiveTab('dice')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'dice'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Dices className="w-3.5 h-3.5" />
            Duelo de Dados
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Stake reminder */}
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                Castigo en juego:
              </span>
              <p className="text-sm font-semibold text-white">{bet.stake}</p>
            </div>
          </div>

          {activeTab === 'decision' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Winner Picker */}
                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1 mb-2">
                    <Trophy className="w-3.5 h-3.5" />
                    Ganador de la Apuesta
                  </span>
                  <div className="space-y-2">
                    {bet.participants.map((part) => {
                      const p = getPana(part.panaId);
                      if (!p) return null;
                      const isSelected = winnerId === p.id;
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setWinnerId(p.id);
                            // Auto select other as loser
                            const other = bet.participants.find((x) => x.panaId !== p.id);
                            if (other) setLoserId(other.panaId);
                            playClickSound();
                          }}
                          className={`w-full p-2.5 rounded-lg border flex items-center justify-between transition-all ${
                            isSelected
                              ? 'bg-emerald-600/30 border-emerald-400 text-white font-bold'
                              : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span>{p.avatar}</span>
                            <span>{p.name}</span>
                          </div>
                          <span className="text-[11px] text-slate-400">"{part.prediction}"</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Loser Picker */}
                <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/30">
                  <span className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1 mb-2">
                    <Skull className="w-3.5 h-3.5" />
                    El que Paga el Castigo
                  </span>
                  <div className="space-y-2">
                    {bet.participants.map((part) => {
                      const p = getPana(part.panaId);
                      if (!p) return null;
                      const isSelected = loserId === p.id;
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setLoserId(p.id);
                            const other = bet.participants.find((x) => x.panaId !== p.id);
                            if (other) setWinnerId(other.panaId);
                            playClickSound();
                          }}
                          className={`w-full p-2.5 rounded-lg border flex items-center justify-between transition-all ${
                            isSelected
                              ? 'bg-rose-600/30 border-rose-400 text-white font-bold'
                              : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span>{p.avatar}</span>
                            <span>{p.name}</span>
                          </div>
                          <span className="text-[11px] text-slate-400">"{part.prediction}"</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Note / Proof Comment */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Anécdota / Prueba del resultado (opcional)
                </label>
                <input
                  type="text"
                  value={proofNote}
                  onChange={(e) => setProofNote(e.target.value)}
                  placeholder="Ej. Ganó por goleada histórica, Lucas pidió la hora..."
                  className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          )}

          {activeTab === 'roulette' && (
            <div>
              <p className="text-xs text-slate-400 mb-3">
                ¿El castigo original era indeterminado o quieren agregarle picante? Giren la ruleta para definir el castigo final.
              </p>
              <RouletteGame
                items={rouletteItems}
                onSpinEnd={(item) => {
                  setProofNote(`Castigo asignado por la ruleta: ${item.text}`);
                }}
              />
            </div>
          )}

          {activeTab === 'dice' && (
            <div>
              <p className="text-xs text-slate-400 mb-3">
                Tiren los dados directamente para desempatar o decidir al ganador de la apuesta al mejor número.
              </p>
              <DiceGame
                panas={panas}
                defaultPana1Id={bet.participants[0]?.panaId}
                defaultPana2Id={bet.participants[1]?.panaId}
                onWinnerDecided={(wId, lId) => {
                  setWinnerId(wId);
                  setLoserId(lId);
                }}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            {winnerId && loserId && (
              <span>
                🏆 Ganador: <strong className="text-emerald-400">{getPana(winnerId)?.name}</strong> · 
                💀 Paga: <strong className="text-rose-400">{getPana(loserId)?.name}</strong>
              </span>
            )}
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleResolve}
              className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all"
            >
              Confirmar Resolución
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
