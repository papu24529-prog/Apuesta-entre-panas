import React, { useState, useRef, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCw, Plus, Trash2, Sparkles, Trophy, Shuffle } from 'lucide-react';
import { RouletteItem } from '../types';
import { playClickSound, playSpinTickSound, playWinSound } from '../utils/audio';

interface RouletteGameProps {
  items: RouletteItem[];
  onUpdateItems?: (items: RouletteItem[]) => void;
  onSpinEnd?: (selectedItem: RouletteItem) => void;
}

export const RouletteGame: React.FC<RouletteGameProps> = ({
  items: initialItems,
  onUpdateItems,
  onSpinEnd,
}) => {
  const [items, setItems] = useState<RouletteItem[]>(initialItems);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [selectedWinner, setSelectedWinner] = useState<RouletteItem | null>(null);
  const [newPenaltyText, setNewPenaltyText] = useState('');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Sync with prop
  useEffect(() => {
    setItems(initialItems);
  }, [initialItems]);

  const drawWheel = (angle: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = width / 2 - 16;
    const numSlices = items.length;
    const sliceAngle = (2 * Math.PI) / (numSlices || 1);

    ctx.clearRect(0, 0, width, height);

    // Draw outer golden ring
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius + 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.lineWidth = 6;
    ctx.strokeStyle = '#f59e0b';
    ctx.stroke();
    ctx.restore();

    // Draw slices
    items.forEach((item, index) => {
      const startAngle = angle + index * sliceAngle;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();

      ctx.fillStyle = item.color;
      ctx.fill();

      ctx.lineWidth = 2;
      ctx.strokeStyle = '#0f172a';
      ctx.stroke();

      // Text and emoji
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(startAngle + sliceAngle / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 13px sans-serif';
      ctx.shadowColor = 'rgba(0,0,0,0.8)';
      ctx.shadowBlur = 4;
      
      const maxText = item.text.length > 20 ? item.text.slice(0, 18) + '...' : item.text;
      ctx.fillText(maxText, radius - 24, 5);
      ctx.restore();
    });

    // Draw center pin
    ctx.beginPath();
    ctx.arc(centerX, centerY, 24, 0, 2 * Math.PI);
    ctx.fillStyle = '#020617';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#f59e0b';
    ctx.stroke();

    ctx.font = '16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('⚡', centerX, centerY);
  };

  useEffect(() => {
    drawWheel((rotation * Math.PI) / 180);
  }, [rotation, items]);

  const spin = () => {
    if (isSpinning || items.length === 0) return;

    playClickSound();
    setIsSpinning(true);
    setSelectedWinner(null);

    const minSpins = 5;
    const extraSpins = Math.random() * 4;
    const totalRotationDeg = (minSpins + extraSpins) * 360 + Math.random() * 360;
    const duration = 4000;
    const startTime = performance.now();
    const startRotation = rotation % 360;

    let lastTickAngle = 0;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Cubic ease-out
      const ease = 1 - Math.pow(1 - progress, 3);
      const currentAngle = startRotation + totalRotationDeg * ease;

      setRotation(currentAngle);

      // Play tick sound whenever crossing a slice boundary
      const sliceSizeDeg = 360 / items.length;
      if (Math.abs(currentAngle - lastTickAngle) >= sliceSizeDeg) {
        playSpinTickSound();
        lastTickAngle = currentAngle;
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setIsSpinning(false);
        // Calculate winning slice (pointer is at top: 270 deg or -90 deg)
        const finalNormalizedAngle = (currentAngle % 360 + 360) % 360;
        // Pointer is at 270 deg (top)
        const pointerAngle = (270 - finalNormalizedAngle + 360) % 360;
        const sliceDeg = 360 / items.length;
        const winningIndex = Math.floor(pointerAngle / sliceDeg) % items.length;
        const winner = items[winningIndex];

        setSelectedWinner(winner);
        playWinSound();
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });

        if (onSpinEnd && winner) {
          onSpinEnd(winner);
        }
      }
    };

    requestAnimationFrame(animate);
  };

  const handleAddPenalty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPenaltyText.trim()) return;

    const palette = ['#10b981', '#f59e0b', '#6366f1', '#f97316', '#ec4899', '#a855f7', '#06b6d4', '#ef4444'];
    const randomColor = palette[Math.floor(Math.random() * palette.length)];

    const newItem: RouletteItem = {
      id: `r-${Date.now()}`,
      text: newPenaltyText.trim(),
      emoji: '🎯',
      color: randomColor,
    };

    const updated = [...items, newItem];
    setItems(updated);
    if (onUpdateItems) onUpdateItems(updated);
    setNewPenaltyText('');
    playClickSound();
  };

  const handleRemoveItem = (id: string) => {
    if (items.length <= 2) {
      alert('La ruleta debe tener al menos 2 opciones');
      return;
    }
    const updated = items.filter((it) => it.id !== id);
    setItems(updated);
    if (onUpdateItems) onUpdateItems(updated);
    playClickSound();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
      <div className="flex flex-col lg:flex-row items-center gap-8 justify-between">
        {/* Roulette Display with Pointer */}
        <div className="relative flex flex-col items-center">
          {/* Top Indicator Arrow */}
          <div className="absolute -top-3 z-20 flex flex-col items-center drop-shadow-md">
            <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[22px] border-t-amber-400" />
          </div>

          {/* Canvas */}
          <canvas
            ref={canvasRef}
            width={380}
            height={380}
            className="rounded-full max-w-[320px] sm:max-w-[360px] h-auto shadow-2xl transition-transform"
          />

          {/* Spin CTA Button */}
          <div className="mt-6 flex flex-col items-center">
            <button
              onClick={spin}
              disabled={isSpinning || items.length === 0}
              className={`px-8 py-3.5 rounded-2xl font-black text-sm tracking-wider uppercase flex items-center gap-2 shadow-xl transition-all ${
                isSpinning
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed scale-95'
                  : 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:scale-105 text-slate-950 shadow-amber-500/25 active:scale-95'
              }`}
            >
              <RotateCw className={`w-5 h-5 ${isSpinning ? 'animate-spin' : ''}`} />
              {isSpinning ? '¡Girando Castigo...!' : '¡Girar la Ruleta!'}
            </button>
            <span className="text-[11px] text-slate-500 mt-2">
              Haz clic para decidir el castigo de la apuesta al azar
            </span>
          </div>

          {/* Winner Announcement Banner */}
          {selectedWinner && (
            <div className="mt-4 p-4 rounded-xl bg-gradient-to-r from-amber-500/20 via-amber-500/10 to-transparent border border-amber-500/40 text-center animate-in zoom-in-95 duration-200">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center justify-center gap-1.5">
                <Trophy className="w-4 h-4" />
                ¡El Castigo Decidido es!
              </span>
              <h4 className="text-lg font-black text-white mt-1">
                {selectedWinner.text}
              </h4>
            </div>
          )}
        </div>

        {/* Roulette Customizer & Penalties List */}
        <div className="w-full lg:max-w-md bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 flex flex-col h-full">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Opciones de Castigos ({items.length})
            </span>
            <span className="text-[11px] text-slate-500">Personaliza la ruleta</span>
          </div>

          {/* Add custom penalty to roulette */}
          <form onSubmit={handleAddPenalty} className="flex gap-2 mb-3">
            <input
              type="text"
              value={newPenaltyText}
              onChange={(e) => setNewPenaltyText(e.target.value)}
              placeholder="Añadir nuevo castigo..."
              className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            <button
              type="submit"
              className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              Añadir
            </button>
          </form>

          {/* Scrollable list of items */}
          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {items.map((it) => (
              <div
                key={it.id}
                className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900 border border-slate-800/80 text-xs"
              >
                <div className="flex items-center gap-2 truncate">
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: it.color }}
                  />
                  <span className="text-slate-200 truncate">{it.text}</span>
                </div>
                <button
                  onClick={() => handleRemoveItem(it.id)}
                  disabled={items.length <= 2}
                  className="text-slate-500 hover:text-rose-400 p-1 disabled:opacity-30 disabled:cursor-not-allowed"
                  title="Eliminar de la ruleta"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
