import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Coins, Sparkles } from 'lucide-react';
import { playClickSound, playCoinFlipSound, playWinSound } from '../utils/audio';

export const CoinGame: React.FC = () => {
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<'cara' | 'cruz' | null>(null);
  const [rotationCount, setRotationCount] = useState(0);

  const flipCoin = () => {
    if (isFlipping) return;
    setIsFlipping(true);
    setResult(null);
    playCoinFlipSound();

    const isCara = Math.random() > 0.5;
    const flips = 10;
    setRotationCount((prev) => prev + flips * 180 + (isCara ? 0 : 180));

    setTimeout(() => {
      setIsFlipping(false);
      const outcome = isCara ? 'cara' : 'cruz';
      setResult(outcome);
      playWinSound();
      confetti({ particleCount: 40, spread: 50 });
    }, 1500);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col items-center">
      <div className="flex items-center gap-2 mb-6">
        <Coins className="w-5 h-5 text-amber-400" />
        <h3 className="text-base font-bold text-white">Moneda de la Suerte (Cara o Cruz)</h3>
      </div>

      {/* 3D Coin */}
      <div className="relative w-28 h-28 my-4 perspective-1000">
        <div
          className={`w-full h-full rounded-full border-4 border-amber-300 shadow-2xl flex items-center justify-center font-black text-2xl transition-all duration-[1500ms] ${
            isFlipping ? 'scale-110' : ''
          }`}
          style={{
            transform: `rotateY(${rotationCount}deg)`,
            transformStyle: 'preserve-3d',
            background: 'radial-gradient(circle, #f59e0b 0%, #b45309 100%)',
            boxShadow: '0 0 25px rgba(245, 158, 11, 0.4)',
          }}
        >
          <span className="text-slate-950 font-black drop-shadow">
            {result === 'cruz' ? 'CRUZ' : 'CARA'}
          </span>
        </div>
      </div>

      {/* Button */}
      <button
        onClick={flipCoin}
        disabled={isFlipping}
        className={`mt-4 px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all ${
          isFlipping
            ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
            : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 active:scale-95'
        }`}
      >
        <Sparkles className="w-4 h-4" />
        {isFlipping ? 'Lanzando al aire...' : 'Lanzar Moneda'}
      </button>

      {result && (
        <p className="mt-3 text-sm font-bold text-amber-400 animate-in fade-in">
          ¡Cayó <span className="uppercase underline">{result}</span>!
        </p>
      )}
    </div>
  );
};
