import React from 'react';
import { 
  Flame, 
  FileArchive, 
  Plus, 
  Volume2, 
  VolumeX, 
  Tag, 
  Trophy, 
  RotateCw, 
  LayoutGrid, 
  Users
} from 'lucide-react';
import { playClickSound, setMuted } from '../utils/audio';

interface HeaderProps {
  currentTab: 'bets' | 'games' | 'leaderboard' | 'categories';
  onTabChange: (tab: 'bets' | 'games' | 'leaderboard' | 'categories') => void;
  onOpenNewBet: () => void;
  onOpenCategories: () => void;
  onOpenZipModal: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  activeBetsCount: number;
  customCategoriesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  onOpenNewBet,
  onOpenCategories,
  onOpenZipModal,
  isMuted,
  onToggleMute,
  activeBetsCount,
  customCategoriesCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top brand & actions row */}
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo / Lockup */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/20 font-black">
              <Flame className="w-6 h-6 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white uppercase font-sans">
                  Apuesta <span className="text-amber-400">Entre Panas</span>
                </h1>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Retos, birrias y castigos entre amigos · Sin escapatorias
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Audio Toggle */}
            <button
              onClick={() => {
                onToggleMute();
                setMuted(!isMuted);
              }}
              title={isMuted ? 'Activar sonido' : 'Silenciar sonido'}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
            </button>

            {/* Prominent ZIP Download Button */}
            <button
              onClick={() => {
                playClickSound();
                onOpenZipModal();
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-amber-500/40 hover:border-amber-400 text-amber-300 font-bold text-xs rounded-xl shadow-sm transition-all hover:scale-[1.02]"
              title="Descargar código del proyecto en ZIP"
            >
              <FileArchive className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Descargar</span> ZIP
            </button>

            {/* Manage Categories Button */}
            <button
              onClick={() => {
                playClickSound();
                onOpenCategories();
              }}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-all"
            >
              <Tag className="w-3.5 h-3.5 text-amber-400" />
              Categorías
              {customCategoriesCount > 0 && (
                <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded-full font-bold">
                  {customCategoriesCount}
                </span>
              )}
            </button>

            {/* Primary CTA: New Bet */}
            <button
              onClick={() => {
                playClickSound();
                onOpenNewBet();
              }}
              className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              Nueva Apuesta
            </button>
          </div>
        </div>

        {/* Navigation Tabs (Functional interactive filter buttons with clear active state) */}
        <div className="flex items-center gap-1 py-2 overflow-x-auto no-scrollbar border-t border-slate-800/80">
          <button
            onClick={() => {
              playClickSound();
              onTabChange('bets');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
              currentTab === 'bets'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            Muro de Apuestas
            {activeBetsCount > 0 && (
              <span className="text-[10px] text-slate-300 font-mono">({activeBetsCount})</span>
            )}
          </button>

          <button
            onClick={() => {
              playClickSound();
              onTabChange('categories');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
              currentTab === 'categories'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            Categorías Personalizadas
          </button>

          <button
            onClick={() => {
              playClickSound();
              onTabChange('games');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
              currentTab === 'games'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <RotateCw className="w-3.5 h-3.5" />
            Ruleta & Minijuegos
          </button>

          <button
            onClick={() => {
              playClickSound();
              onTabChange('leaderboard');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
              currentTab === 'leaderboard'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            Tabla de Honor & Deudas
          </button>
        </div>
      </div>
    </header>
  );
};
