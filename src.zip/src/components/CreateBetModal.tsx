import React, { useState } from 'react';
import { X, Plus, Swords, Calendar, Tag, Dices, RotateCw, Users2, Trophy } from 'lucide-react';
import { Bet, BetCategory, Pana } from '../types';
import { playClickSound } from '../utils/audio';

interface CreateBetModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: BetCategory[];
  panas: Pana[];
  onCreateBet: (newBet: Omit<Bet, 'id' | 'createdAt'>) => void;
  onOpenCategoryManager: () => void;
  defaultCategoryId?: string;
}

const STAKE_PRESETS = [
  '🍻 Caja de cervezas frías',
  '🍕 Pizza familiar con borde de queso',
  '🏋️ 50 flexiones en vivo ante los panas',
  '📸 Foto vergonzosa de WhatsApp 24h',
  '👕 Camiseta del rival puesta un día',
  '🍔 Combo de hamburguesas para todos',
  '🎤 Cantar karaoke a capella en video',
  '☕ Invitar los cafés de toda la semana',
];

export const CreateBetModal: React.FC<CreateBetModalProps> = ({
  isOpen,
  onClose,
  categories,
  panas,
  onCreateBet,
  onOpenCategoryManager,
  defaultCategoryId,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState(defaultCategoryId || (categories[0]?.id ?? ''));
  const [stake, setStake] = useState('');
  const [creatorPanaId, setCreatorPanaId] = useState(panas[0]?.id ?? '');
  const [challengerPanaId, setChallengerPanaId] = useState(panas[1]?.id ?? '');
  const [creatorPick, setCreatorPick] = useState('');
  const [challengerPick, setChallengerPick] = useState('');
  const [resolutionMethod, setResolutionMethod] = useState<'manual' | 'roulette' | 'dice' | 'voting'>('manual');
  const [dueDate, setDueDate] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Escribe un título para la apuesta');
      return;
    }
    if (!stake.trim()) {
      setError('Define el castigo o prenda de la apuesta');
      return;
    }
    if (creatorPanaId === challengerPanaId) {
      setError('El creador y el rival deben ser panas diferentes');
      return;
    }

    playClickSound();

    onCreateBet({
      title: title.trim(),
      description: description.trim() || undefined,
      categoryId,
      stake: stake.trim(),
      creatorPanaId,
      participants: [
        {
          panaId: creatorPanaId,
          prediction: creatorPick.trim() || 'A favor de su pronóstico',
          status: 'accepted',
        },
        {
          panaId: challengerPanaId,
          prediction: challengerPick.trim() || 'A favor de la contra',
          status: 'accepted',
        },
      ],
      status: 'active',
      resolutionMethod,
      dueDate: dueDate || undefined,
    });

    onClose();
  };

  const selectedCategory = categories.find((c) => c.id === categoryId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Lanzar Nueva Apuesta</h2>
              <p className="text-xs text-slate-400">Elige la categoría, los panas participantes y el castigo</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <p className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3 py-2 rounded-lg">
              {error}
            </p>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Título de la Apuesta *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setError('');
              }}
              placeholder="Ej. Final de Champions, Reto de 100 abdominales, Quién llega primero..."
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              autoFocus
            />
          </div>

          {/* Category Selection with Instant Custom Category Creator trigger */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-amber-400" />
                Categoría de la Apuesta *
              </label>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  onOpenCategoryManager();
                }}
                className="text-xs font-semibold text-amber-400 hover:text-amber-300 hover:underline flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Crear Categoría Personalizada
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {categories.map((cat) => {
                const isSelected = cat.id === categoryId;
                return (
                  <button
                    type="button"
                    key={cat.id}
                    onClick={() => {
                      playClickSound();
                      setCategoryId(cat.id);
                    }}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-amber-400 bg-slate-800 shadow-md ring-1 ring-amber-400/50'
                        : 'border-slate-800 bg-slate-800/40 hover:bg-slate-800/70 text-slate-300'
                    }`}
                  >
                    <span className="text-lg">{cat.icon}</span>
                    <div className="truncate">
                      <div className="text-xs font-medium text-white truncate">{cat.name}</div>
                      {cat.isCustom && (
                        <div className="text-[10px] text-amber-400 font-semibold">Personalizada</div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {selectedCategory && (
              <div className="mt-2 text-xs text-slate-400 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/30 border border-slate-800">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: selectedCategory.color }} />
                <span>{selectedCategory.description}</span>
              </div>
            )}
          </div>

          {/* Stake / El Castigo */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              El Castigo / Lo que se Paga *
            </label>
            <input
              type="text"
              value={stake}
              onChange={(e) => {
                setStake(e.target.value);
                setError('');
              }}
              placeholder="¿Qué paga el que pierde? (cervezas, pizza, flexiones, foto en WhatsApp...)"
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            {/* Quick Stake Suggestions */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {STAKE_PRESETS.map((preset) => (
                <button
                  type="button"
                  key={preset}
                  onClick={() => {
                    playClickSound();
                    setStake(preset);
                  }}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-300 transition-colors"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Panas in Battle (1v1) */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Users2 className="w-3.5 h-3.5 text-amber-400" />
              Panas en Duelo
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Creator */}
              <div className="space-y-1.5">
                <label className="text-xs text-slate-400 font-medium">Pana 1 (Creador)</label>
                <select
                  value={creatorPanaId}
                  onChange={(e) => setCreatorPanaId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  {panas.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.avatar} {p.name} "{p.nickname}" ({p.victories}V - {p.losses}D)
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={creatorPick}
                  onChange={(e) => setCreatorPick(e.target.value)}
                  placeholder="Pronóstico o postura de este pana"
                  className="w-full px-3 py-1.5 bg-slate-900/60 border border-slate-700/60 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Challenger */}
              <div className="space-y-1.5">
                <label className="text-xs text-slate-400 font-medium">Pana 2 (Rival)</label>
                <select
                  value={challengerPanaId}
                  onChange={(e) => setChallengerPanaId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  {panas.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.avatar} {p.name} "{p.nickname}" ({p.victories}V - {p.losses}D)
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={challengerPick}
                  onChange={(e) => setChallengerPick(e.target.value)}
                  placeholder="Pronóstico o postura del rival"
                  className="w-full px-3 py-1.5 bg-slate-900/60 border border-slate-700/60 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Resolution Method */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
              Método de Resolución del Ganador
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setResolutionMethod('manual');
                }}
                className={`p-3 rounded-xl border text-center transition-all ${
                  resolutionMethod === 'manual'
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-white'
                }`}
              >
                <Trophy className="w-5 h-5 mx-auto mb-1 text-amber-400" />
                <div className="text-xs font-bold">Manual / Real</div>
                <div className="text-[10px] opacity-70">Resultado real</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setResolutionMethod('roulette');
                }}
                className={`p-3 rounded-xl border text-center transition-all ${
                  resolutionMethod === 'roulette'
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-white'
                }`}
              >
                <RotateCw className="w-5 h-5 mx-auto mb-1 text-emerald-400" />
                <div className="text-xs font-bold">Ruleta</div>
                <div className="text-[10px] opacity-70">Girar la ruleta</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setResolutionMethod('dice');
                }}
                className={`p-3 rounded-xl border text-center transition-all ${
                  resolutionMethod === 'dice'
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-white'
                }`}
              >
                <Dices className="w-5 h-5 mx-auto mb-1 text-indigo-400" />
                <div className="text-xs font-bold">Dados 1v1</div>
                <div className="text-[10px] opacity-70">Tirada de dados</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setResolutionMethod('voting');
                }}
                className={`p-3 rounded-xl border text-center transition-all ${
                  resolutionMethod === 'voting'
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-white'
                }`}
              >
                <Users2 className="w-5 h-5 mx-auto mb-1 text-purple-400" />
                <div className="text-xs font-bold">Votación</div>
                <div className="text-[10px] opacity-70">Jurado de panas</div>
              </button>
            </div>
          </div>

          {/* Date and Optional Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-400 font-medium mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                Fecha límite (opcional)
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 font-medium mb-1">
                Detalles / Reglas adicionales
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Reglas especiales de la birria o el juego..."
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.02]"
            >
              Publicar Apuesta 🔥
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
