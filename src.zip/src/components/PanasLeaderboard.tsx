import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Skull, Plus, CheckCircle2, AlertTriangle, ShieldCheck, UserPlus } from 'lucide-react';
import { Pana, Bet } from '../types';
import { playClickSound, playWinSound } from '../utils/audio';

interface PanasLeaderboardProps {
  panas: Pana[];
  bets: Bet[];
  onAddPana: (pana: Omit<Pana, 'id' | 'victories' | 'losses' | 'pendingDebts'>) => void;
  onPayDebt: (betId: string) => void;
}

const AVATAR_OPTIONS = ['⚽', '🎲', '🏎️', '🍕', '🧠', '👑', '🔥', '🥊', '🍺', '🌮', '🎯', '🕶️', '⚡'];

export const PanasLeaderboard: React.FC<PanasLeaderboardProps> = ({
  panas,
  bets,
  onAddPana,
  onPayDebt,
}) => {
  const [isAddingPana, setIsAddingPana] = useState(false);
  const [name, setName] = useState('');
  const [nickname, setNickname] = useState('');
  const [avatar, setAvatar] = useState('👑');

  // Sort panas by victory count then by winrate
  const sortedPanas = [...panas].sort((a, b) => {
    if (b.victories !== a.victories) return b.victories - a.victories;
    const rateA = a.victories / (a.victories + a.losses || 1);
    const rateB = b.victories / (b.victories + b.losses || 1);
    return rateB - rateA;
  });

  // Pending debts from resolved bets where debtor hasn't marked as paid
  const pendingDebts = bets.filter(
    (b) => b.status === 'resolved' && b.loserPanaId && !b.proofNote?.includes('[PAGADO]')
  );

  const getPana = (id?: string) => panas.find((p) => p.id === id);

  const handleCreatePana = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    playClickSound();
    onAddPana({
      name: name.trim(),
      nickname: nickname.trim() || 'El Nuevo Pana',
      avatar,
      color: '#f59e0b',
    });

    setName('');
    setNickname('');
    setIsAddingPana(false);
  };

  return (
    <div className="space-y-8">
      {/* Top Banner & Leaderboard */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-5 border-b border-slate-800 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              <h2 className="text-lg font-bold text-white">Tabla de Honor & Panas</h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Estadísticas oficiales de victorias, derrotas y honor en las apuestas
            </p>
          </div>

          {!isAddingPana ? (
            <button
              onClick={() => {
                playClickSound();
                setIsAddingPana(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-white rounded-xl transition-all self-start sm:self-auto"
            >
              <UserPlus className="w-4 h-4 text-amber-400" />
              Añadir Nuevo Amigo
            </button>
          ) : (
            <form onSubmit={handleCreatePana} className="flex flex-wrap items-center gap-2">
              <input
                type="text"
                placeholder="Nombre"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
                autoFocus
              />
              <input
                type="text"
                placeholder="Apodo (ej. El Capi)"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
              <select
                value={avatar}
                onChange={(e) => setAvatar(e.target.value)}
                className="px-2 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              >
                {AVATAR_OPTIONS.map((em) => (
                  <option key={em} value={em}>{em}</option>
                ))}
              </select>
              <button
                type="submit"
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg"
              >
                Guardar
              </button>
              <button
                type="button"
                onClick={() => setIsAddingPana(false)}
                className="text-xs text-slate-400 hover:text-white px-2 py-1"
              >
                ✕
              </button>
            </form>
          )}
        </div>

        {/* Panas Ranking Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3">Puesto</th>
                <th className="py-3 px-3">Pana</th>
                <th className="py-3 px-3 text-center">Victorias</th>
                <th className="py-3 px-3 text-center">Derrotas</th>
                <th className="py-3 px-3 text-center">Efectividad</th>
                <th className="py-3 px-3 text-right">Estado de Deudas</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {sortedPanas.map((pana, index) => {
                const total = pana.victories + pana.losses;
                const winRate = total > 0 ? Math.round((pana.victories / total) * 100) : 0;
                const isLeader = index === 0;

                return (
                  <tr
                    key={pana.id}
                    className={`hover:bg-slate-800/30 transition-colors ${
                      isLeader ? 'bg-amber-500/5' : ''
                    }`}
                  >
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-1.5">
                        {index === 0 && <span className="text-amber-400 font-black">🥇 1º</span>}
                        {index === 1 && <span className="text-slate-300 font-black">🥈 2º</span>}
                        {index === 2 && <span className="text-amber-700 font-black">🥉 3º</span>}
                        {index > 2 && <span className="text-slate-500 font-mono">#{index + 1}</span>}
                      </div>
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">{pana.avatar}</span>
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            {pana.name}
                            {isLeader && (
                              <span className="text-[10px] text-amber-400 font-bold">
                                👑 Rey de la Birria
                              </span>
                            )}
                          </div>
                          <div className="text-slate-400 text-[11px]">"{pana.nickname}"</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-center font-bold text-emerald-400">
                      {pana.victories}
                    </td>
                    <td className="py-3.5 px-3 text-center font-bold text-rose-400">
                      {pana.losses}
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1 font-mono">
                        <span className="text-white font-bold">{winRate}%</span>
                        <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden hidden sm:block">
                          <div
                            className="h-full bg-emerald-500 rounded-full"
                            style={{ width: `${winRate}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      {pana.pendingDebts > 0 ? (
                        <span className="text-rose-400 font-bold text-[11px] inline-flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                          Debe {pana.pendingDebts} castigo{pana.pendingDebts > 1 ? 's' : ''}
                        </span>
                      ) : (
                        <span className="text-emerald-400 text-[11px] inline-flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          Al día y en paz
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* "El Muro de Deudas y Castigos Pendientes" */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-800">
          <Skull className="w-5 h-5 text-rose-400" />
          <div>
            <h3 className="text-base font-bold text-white">El Muro de Castigos Pendientes</h3>
            <p className="text-xs text-slate-400">Quién le debe qué a quién · Las deudas de honor se pagan</p>
          </div>
        </div>

        {pendingDebts.length === 0 ? (
          <div className="p-8 text-center bg-slate-950/40 rounded-xl border border-slate-800/80">
            <ShieldCheck className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
            <h4 className="text-sm font-bold text-white">¡No hay deudas pendientes entre los panas!</h4>
            <p className="text-xs text-slate-400 mt-1">Todos los castigos han sido cumplidos con honor.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingDebts.map((bet) => {
              const loser = getPana(bet.loserPanaId);
              const winner = getPana(bet.winnerPanaId);

              return (
                <div
                  key={bet.id}
                  className="p-4 rounded-xl bg-slate-950/70 border border-rose-500/20 hover:border-rose-500/40 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="text-[11px] text-slate-400 mb-1 font-semibold truncate">
                      {bet.title}
                    </div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">{loser?.avatar}</span>
                      <div className="truncate">
                        <span className="font-bold text-rose-400">{loser?.name}</span>
                        <span className="text-slate-400 text-xs"> le debe a </span>
                        <span className="font-bold text-emerald-400">{winner?.name}</span>
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-semibold text-amber-300">
                      🎁 {bet.stake}
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">Pendiente de pagar</span>
                    <button
                      onClick={() => {
                        playWinSound();
                        confetti({ particleCount: 50, spread: 60 });
                        onPayDebt(bet.id);
                      }}
                      className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1 shadow-sm"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Marcar como Pagado
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
