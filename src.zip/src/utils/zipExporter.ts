import JSZip from 'jszip';
import { Bet, BetCategory, Pana } from '../types';

export async function exportProjectToZip(currentData?: {
  bets: Bet[];
  categories: BetCategory[];
  panas: Pana[];
}) {
  const zip = new JSZip();

  // 1. Add README.md
  zip.file(
    'README.md',
    `# 🍻 Apuesta Entre Panas - App Completa

¡Bienvenido a la aplicación **Apuesta Entre Panas**!
Esta app permite gestionar apuestas amistosas, crear categorías personalizadas, resolver empates con la Ruleta de Castigos o Dados, y llevar el historial de deudas y honor entre amigos.

## 🚀 Cómo correr este proyecto en tu computadora

1. Asegúrate de tener instalado [Node.js](https://nodejs.org/) (versión 18 o superior).
2. Abre la carpeta del proyecto en tu terminal.
3. Instala las dependencias:
   \`\`\`bash
   npm install
   \`\`\`
4. Inicia el servidor de desarrollo:
   \`\`\`bash
   npm run dev
   \`\`\`
5. Abre en tu navegador \`http://localhost:3000\` o la URL indicada en la terminal.

## ⚙️ Tecnologías usadas
- React 19 + TypeScript
- Vite
- Tailwind CSS v4
- Canvas Confetti
- Web Audio API (efectos de sonido arcade sin archivos externos)
- JSZip para exportación y respaldo

## 📋 Categorías y Apuestas
Crea tus propias categorías personalizadas con iconos y colores temáticos, lanza desafíos con tus panas y no dejes que nadie se escape de pagar el castigo.
`
  );

  // 2. Add package.json
  const packageJson = {
    name: "apuesta-entre-panas",
    private: true,
    version: "1.0.0",
    type: "module",
    scripts: {
      dev: "vite --port 3000",
      build: "vite build",
      preview: "vite preview"
    },
    dependencies: {
      "canvas-confetti": "^1.9.4",
      "jszip": "^3.10.1",
      "lucide-react": "^0.546.0",
      "motion": "^12.23.24",
      "react": "^19.0.1",
      "react-dom": "^19.0.1"
    },
    devDependencies: {
      "@tailwindcss/vite": "^4.3.3",
      "@types/canvas-confetti": "^1.9.0",
      "@types/node": "^22.14.0",
      "@types/react": "^19.3.0",
      "@types/react-dom": "^19.3.0",
      "@vitejs/plugin-react": "^6.1.1",
      "tailwindcss": "^4.3.3",
      "typescript": "^7.0.2",
      "vite": "^8.3.0"
    }
  };
  zip.file('package.json', JSON.stringify(packageJson, null, 2));

  // 3. Add configuration files
  zip.file('tsconfig.json', JSON.stringify({
    compilerOptions: {
      target: "ES2022",
      module: "ESNext",
      moduleResolution: "bundler",
      jsx: "react-jsx",
      strict: true,
      skipLibCheck: true
    }
  }, null, 2));

  zip.file('vite.config.ts', `import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 3000,
  },
});
`);

  zip.file('index.html', `<!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Apuesta Entre Panas</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  </head>
  <body class="bg-slate-950 text-slate-100 font-['Plus_Jakarta_Sans',sans-serif] min-h-screen">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`);

  // 4. Source folder
  const src = zip.folder('src');
  if (src) {
    src.file('index.css', `@import "tailwindcss";\n`);
    src.file('main.tsx', `import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);\n`);
  }

  // 5. If user data was provided, embed current data backup
  if (currentData) {
    const backupData = {
      exportedAt: new Date().toISOString(),
      appName: "Apuesta Entre Panas",
      categories: currentData.categories,
      bets: currentData.bets,
      panas: currentData.panas,
    };
    zip.file('data/backup-apuestas.json', JSON.stringify(backupData, null, 2));
  }

  // Generate zip as Blob
  const blob = await zip.generateAsync({ type: 'blob' });
  
  // Trigger direct browser download
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `apuesta-entre-panas-proyecto.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
